Stap 1
------
Download en Installeer .net Framework 4.6 (https://download.microsoft.com/download/D/5/C/D5C98AB0-35CC-45D9-9BA5-B18256BA2AE6/NDP462-KB3151802-Web.exe)
Dit dien je alleen de 1ste keer te doen. 

Stap 2
------
Dubbelklik op Cloximmo.be(exe)

Stap 3
------
Heb even geduld, tot de progressbalk volgelopen is.
De panden worden nu ingelezen

Stap 4
------
Druk op eender welke knop om de applicatie te sluiten